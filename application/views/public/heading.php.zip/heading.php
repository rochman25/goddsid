	<!-- header desktop -->
	<header class="desktop">
	    <div class="header-fixed">
	        <div class="top-bar">
	            <style>
body{
    margin: 0;
    padding: 0;
    width: 100%;
}
#hellobar-bar {
    font-family: "Open Sans", sans-serif;
    width: 100%;
    margin: 0;
    height: 30px;
    display: table;
    font-size: 17px;
    font-weight: 400;
    padding: .33em .5em;
    -webkit-font-smoothing: antialiased;
    color: #5c5e60;
    position: fixed;
    background-color: white;
    box-shadow: 0 1px 3px 2px rgba(0,0,0,0.15);
}
#hellobar-bar.regular {
    height: 30px;
    font-size: 14px;
    padding: .2em .5em;
}
.hb-content-wrapper {
    text-align: center;
    text-align: center;
    position: relative;
    display: table-cell;
    vertical-align: middle;
}
.hb-content-wrapper p {
    margin-top: 0;
    margin-bottom: 0;
}
.hb-text-wrapper {
    margin-right: .67em;
    display: inline-block;
    line-height: 1.3;
}
.hb-text-wrapper .hb-headline-text {
    font-size: 1em;
    display: inline-block;
    vertical-align: middle;
}
#hellobar-bar .hb-cta {
    display: inline-block;
    vertical-align: middle;
    margin: 5px 0;
    color: #ffffff;
    background-color: #0099cc;
    border-color: #0099cc;
}
.hb-cta-button {
    opacity: 1;
    color: #fff;
    display: block;
    cursor: pointer;
    line-height: 1.5;
    max-width: 22.5em;
    text-align: center;
    position: relative;
    border-radius: 3px;
    white-space: nowrap;
    margin: 1.75em auto 0;
    text-decoration: none;
    padding: 0;
    overflow: hidden;
}
.hb-cta-button .hb-text-holder {
    border-radius: inherit;
    padding: 5px 15px;
}
.hb-close-wrapper {
    display: table-cell;
    width: 1.6em;
}
.hb-close-wrapper .icon-close {
    font-size: 14px;
    top: 15px;
    right: 25px;
    width: 15px;
    height: 15px;
    opacity: .3;
    color: #000;
    cursor: pointer;
    position: absolute;
    text-align: center;
    line-height: 15px;
    z-index: 1000;
    text-decoration: none;
}
</style>
</head>
<body>
<div id="hellobar-bar" class="regular closable">
    <div class="hb-content-wrapper">
        <div class="hb-text-wrapper">
            <div class="hb-headline-text">
                <p><span>Information, untuk pemesanan terhitung tanggal 10 mei 2021 akan di kirim setelah lebaran ya men.</span></p>
            </div>
        </div>
        <a href="javascript:void(0);" class="icon-close" onClick="$('#hellobar-bar').fadeOut()">&#10006;</a>
            <div class="icon-close">
            </div>
        </a>
    </div>
</div>

	        </div>
	        <div class="subheader">
	            <a href="<?= base_url() ?>" class="slogan">
	                #TheBasic
	            </a>
	            <ul>

	                <li><a href="<?= base_url() ?>panduan/retur">Garansi</a></li>
            <li><a href=" <?= base_url() ?>panduan/pemesanan">Cara Pemesanan</a> </li> <li><a href="<?= base_url() ?>panduan/ukuran">Panduan Ukuran</a></li>
	            </ul>
	        </div>
	        <div class="mainheader">
	            <a href="<?= base_url() ?>" class="logo">
	                <img src="<?= base_url() ?>assets/images/logo.png">
	            </a>
	            <ul>
	                <li>
	                    <a href="#">koleksi</a>
	                    <div class="dropdown dropdown-collection">
	                        <div class="dropdown-wrapper">
								<?php foreach($kategori as $key => $item){ ?>
	                            <div class="collections">
	                                <div class="">
	                                    <a href="<?= base_url(); ?>produk/<?=$item['nama_kategori']?>">
	                                        <!-- <div class="gradient"></div> -->
	                                        <!-- <img src="<?= base_url() ?>assets/images/Celana/Celana-BG.png" alt="Sepatu"> -->
	                                        <h2 style="font-size: 20px;"><?=$item['nama_kategori']?></h2>
	                                    </a>
	                                </div>
	                                <ul>
	                                </ul>
								</div>
								<?php } ?>
	                            <!-- <div class="collections">
	                                <div class="">
	                                    <a href="<?= base_url(); ?>produk/jas">
	                                        <div class="gradient"></div>
	                                        <img src="<?= base_url() ?>assets/images/Jas/Jas-BG.png" alt="Tas">
	                                        <h2>Jas</h2>
	                                    </a>
	                                </div>
	                                <ul>
	                                </ul>
	                            </div>
	                            <div class="collections">
	                                <div class="">
	                                    <a href="<?= base_url(); ?>produk/kemeja">
	                                        <div class="gradient"></div>
	                                        <img src="<?= base_url() ?>assets/images/Kemeja/Kemeja-BG.png" alt="Apparel">
	                                        <h2>Kemeja</h2>
	                                    </a>
	                                </div>
	                                <ul>
	                                </ul>
	                            </div>
	                            <div class="right-collection">
	                                <ul>
	                                </ul>
	                            </div> -->
	                        </div>
	                    </div>
	                </li>
	                <li>
	                    <a href="<?= base_url()?>profil">
	                        <span>konfirmasi pembayaran</span>
	                    </a>
	                </li>
	            </ul>
	            <div class="header-right">
	                <div class="icon-right icon-login">
	                    <a href="<?= base_url() ?>keluar">
	                        <i class="svg_icon__header_login svg-icon"></i>
	                    </a>
	                </div>
	                <div class="icon-right icon-cart">
	                    <a href="javascript:;">
	                        <i class="svg_icon__header_cart svg-icon"><span class="notif">0</span></i>
	                    </a>
	                </div>
	                <div class="icon-right icon-wishlist">
	                    <a href="<?= base_url() ?>profil">
	                        <i class="svg_icon__wishlist svg-icon"></i>
	                    </a>
	                </div>
	                <div class="search">
	                    <form action="<?= base_url()?>search" method="get">
	                        <button type="submit"><i class="svg_icon__header_search svg-icon"></i></button>
	                        <input type="text" name="search" class="autocomplete" placeholder="Masukan Kata Kunci">
	                    </form>
	                </div>
	            </div>
	        </div>
	    </div>
	</header>