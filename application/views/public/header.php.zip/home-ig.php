<section class="ig">
        <i class="svg-icon svg_icon__home_ig"></i>
        <h1>@mensrepublicid</h1>
        <div class="ig-wrapper">
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B4lvnfunkbf/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/72873045_207550940236478_8056692629793267852_n.jpg" alt="">
                    <div class="name">@jefftambunan</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/Bx80HO8Hgql/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/60201065_111542350090292_7318687170320014933_n.jpg" alt="">
                    <div class="name">@imamturmudzi02</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B60abheBrid/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/79029232_2491218494453014_1461174711221388371_n.jpg" alt="">
                    <div class="name">@samlakoe</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/ByoOJaBHW9T/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/61988800_350602582267770_4107249759417495714_n.jpg" alt="">
                    <div class="name">@imamturmudzi02</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B2YiHX3gUQk/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/69457240_129676065029105_6051779168081542719_n.jpg" alt="">
                    <div class="name">@alvi_arf</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B3UMpfsArFv/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/71350968_131981784849503_7790091344574761927_n.jpg" alt="">
                    <div class="name">@rezapadillah</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B0s_gx8HbIP/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/66063773_102404424382245_3246465304047781631_n.jpg" alt="">
                    <div class="name">@affan_setiawan</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B65xXIkgtJm/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/81026216_143569577068037_2298902170092401982_n.jpg" alt="">
                    <div class="name">@mariosaskara</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/BsUG53oApu3/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/47582863_331093057495523_6862636901093617017_n.jpg" alt="">
                    <div class="name">@apitooo</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B4VTA4ThIv4/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/73381129_150196632923645_7719142426033167605_n.jpg" alt="">
                    <div class="name">@wahid90s</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/Bz_-90SHscv/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/66465521_337092923905975_9024744333349978119_n.jpg" alt="">
                    <div class="name">@imamturmudzi02</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B617CwDF1ap/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/79169356_927528687644756_7048240626464927437_n.jpg" alt="">
                    <div class="name">@dika_kaputra</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B3qyY5dhVG4/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/71139825_140476133910300_4610694754893189471_n.jpg" alt="">
                    <div class="name">@putriapangestu</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B3GHJhjA4Ff/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/69356867_162016671614422_7101792580325164527_n.jpg" alt="">
                    <div class="name">@radityadk</div>
                </a>
            </div>
                        <div class="ig-card">
                <a href="https://www.instagram.com/p/B0Z3O5RnzPn/" target="_blank">
                    <img src="https://www.mensrepublic.id/assets/images/uploads/instagram/desktop/67386682_2591875254164633_4918606322700969729_n.jpg" alt="">
                    <div class="name">@why_ajie</div>
                </a>
            </div>
                    </div>
    </section>